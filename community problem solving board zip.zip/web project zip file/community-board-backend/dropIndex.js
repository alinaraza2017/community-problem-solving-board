const mongoose = require('mongoose');
require('dotenv').config();
const User = require('./models/User');

async function dropFullNameIndex() {
  try {
    await mongoose.connect(process.env.MONGO_URI);
    console.log('MongoDB connected');

    // Drop the problematic index
    await User.collection.dropIndex('fullName_1');
    console.log('fullName index dropped ✅');

    process.exit(0);
  } catch (err) {
    console.error('Error dropping index:', err);
    process.exit(1);
  }
}

dropFullNameIndex();
