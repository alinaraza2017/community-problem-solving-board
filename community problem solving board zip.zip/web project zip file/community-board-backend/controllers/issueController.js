const Issue = require('../models/Issue');
const path = require('path');

exports.createIssue = async (req, res) => {
  try {
    const { title, description, category, location } = req.body;
    let image = '';
    if (req.file) { // multer puts file on req.file
      image = `/uploads/${req.file.filename}`; // BASE_URL + this later
    }
    const issue = await Issue.create({ title, description, category, location, image });
    res.status(201).json(issue);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getIssues = async (req, res) => {
  try {
    // filters: category, status, sort
    const { category, status, sort, page = 1, limit = 12, q } = req.query;
    const filter = {};
    if (category) filter.category = category;
    if (status) filter.status = status;
    if (q) filter.$or = [{ title: new RegExp(q, 'i') }, { description: new RegExp(q, 'i') }];

    let query = Issue.find(filter);

    // sorting
    if (sort === 'votes_desc') query = query.sort({ upvotes: -1 });
    else if (sort === 'votes_asc') query = query.sort({ upvotes: 1 });
    else query = query.sort({ createdAt: -1 });

    // pagination
    const skip = (page - 1) * limit;
    const total = await Issue.countDocuments(filter);
    const issues = await query.skip(skip).limit(+limit).exec();

    res.json({ issues, total, page: +page, pages: Math.ceil(total / limit) });
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.getIssue = async (req, res) => {
  try {
    const issue = await Issue.findById(req.params.id);
    if (!issue) return res.status(404).json({ message: 'Issue not found' });
    res.json(issue);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.upvoteIssue = async (req, res) => {
  try {
    const issue = await Issue.findById(req.params.id);
    if (!issue) return res.status(404).json({ message: 'Issue not found' });
    issue.upvotes = (issue.upvotes || 0) + 1;
    await issue.save();
    res.json(issue);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};

exports.updateStatus = async (req, res) => {
  try {
    const { status } = req.body;
    const issue = await Issue.findByIdAndUpdate(req.params.id, { status }, { new: true });
    res.json(issue);
  } catch (err) {
    res.status(500).json({ message: err.message });
  }
};
