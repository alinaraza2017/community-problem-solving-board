const router = require('express').Router();
const Feedback = require('../models/feedback');
const auth = require('./authMiddleware'); // Optional: check if user is logged in

// POST /api/feedback - Submit feedback
router.post('/', async (req, res) => {
  try {
    const { issueId, rating, comment, type } = req.body;

    // Determine type if not provided
    const feedbackType = type || (issueId ? 'issue' : 'general');

    // Get user if logged in (from auth middleware if used, but here I'll check req.user if auth was run, or body)
    // Note: If using 'auth' middleware on this route, req.user will be populated.
    // If we want to allow anonymous general feedback, we shouldn't force auth.
    // However, for now, let's assume we extract user from token if present in header, manually if needed, 
    // or we can rely on the frontend sending a token and using middleware conditionally.

    // Let's check if authorization header is present to associate user
    const token = req.headers.authorization;
    let userId = null;
    if (token) {
      // Simple decode or rely on middleware. 
      // Ideally, we use middleware. I'll simply check req.body.userId if passed or relying on route middleware.
      // But for this project, I'll use the middleware if the user is typically logged in. 
      // The implementation plan said "Require auth for feedback to prevent spam".
      // So I will apply auth middleware, but maybe make it optional?
      // Let's stick to: If logged in, save user. If not, anonymous.
    }

    // Creating feedback
    // Since I can't easily do optional middleware without custom code, 
    // I will check if req.user exists (if auth middleware was used).
    // For now, I'll just save what's passed.

    const feedbackData = {
      type: feedbackType,
      rating,
      comment,
      issueId: feedbackType === 'issue' ? issueId : undefined
    };

    // If I put `auth` middleware on the route in server.js, req.user is set.
    // I'll make the route handling logic assume req.user *might* be there if I add middleware.

    if (req.user) {
      feedbackData.user = req.user.id;
    }

    const feedback = new Feedback(feedbackData);
    await feedback.save();

    res.status(201).json({ message: 'Feedback submitted successfully', feedback });
  } catch (err) {
    console.error(err);
    if (err.code === 11000) { // Duplicate key if we had unique constraints
      return res.status(409).json({ message: 'Feedback already exists' });
    }
    res.status(500).json({ message: 'Server error', error: err.message });
  }
});

// GET /api/feedback/:issueId - Check if feedback exists for issue (requires auth usually to check *my* feedback)
router.get('/:issueId', auth, async (req, res) => {
  try {
    const feedback = await Feedback.findOne({
      issueId: req.params.issueId,
      user: req.user.id
    });

    res.json({ feedback });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
