const router = require('express').Router();
const User = require('../models/User');
const Issue = require('../models/Issue');
const auth = require('./authMiddleware');

// Middleware to ensure user is admin
const adminAuth = (req, res, next) => {
  if (req.user && req.user.role === 'admin') {
    next();
  } else {
    res.status(403).json({ message: 'Access denied. Admin only.' });
  }
};

// GET ADMIN STATS
router.get('/stats', auth, adminAuth, async (req, res) => {
  try {
    const totalUsers = await User.countDocuments();
    const totalIssues = await Issue.countDocuments();
    const resolvedIssues = await Issue.countDocuments({ status: 'resolved' });
    const activeIssues = totalIssues - resolvedIssues;

    // Group issues by category
    const issuesByCategory = await Issue.aggregate([
      { $group: { _id: "$category", count: { $sum: 1 } } }
    ]);

    // Top voted issues
    const topVoted = await Issue.find().sort({ votes: -1 }).limit(5);

    // Activity over time (last 7 days) - Mocked for now or aggregate
    // const activity = ...

    res.json({
      totalUsers,
      totalIssues,
      resolvedIssues,
      activeIssues,
      topVoted,
      issuesByCategory
    });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// UPDATE ISSUE STATUS (Admin Override)
router.put('/issues/:id/status', auth, adminAuth, async (req, res) => {
  try {
    const { status } = req.body;
    if (!['reported', 'in progress', 'resolved'].includes(status)) {
      return res.status(400).json({ message: 'Invalid status' });
    }

    const issue = await Issue.findByIdAndUpdate(
      req.params.id,
      { status },
      { new: true }
    );

    if (!issue) return res.status(404).json({ message: 'Issue not found' });

    res.json(issue);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE ISSUE (Admin)
router.delete('/issues/:id', auth, adminAuth, async (req, res) => {
  try {
    const issue = await Issue.findByIdAndDelete(req.params.id);
    if (!issue) return res.status(404).json({ message: 'Issue not found' });
    res.json({ message: 'Issue deleted successfully' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
