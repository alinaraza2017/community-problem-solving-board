const router = require('express').Router();
const User = require('../models/User');

const auth = require('./authMiddleware');

// GET ALL USERS (Admin only)
router.get('/', auth, async (req, res) => {
  try {
    if (req.user.role !== 'admin') {
      return res.status(403).json({ message: "Access denied" });
    }
    const users = await User.find().select('-password'); // Hide password
    res.json(users);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET SINGLE USER (Profile page)
router.get('/:id', async (req, res) => {
  try {
    const user = await User.findById(req.params.id).select('-password');
    if (!user) return res.status(404).json({ message: "User not found" });

    res.json(user);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// UPDATE USER PROFILE
router.put('/:id', auth, async (req, res) => {
  try {
    // Check if user is updating their own profile
    if (req.user.id !== req.params.id && req.user.role !== 'admin') {
      return res.status(403).json({ message: "You can only update your own profile" });
    }

    const allowedUpdates = ['username', 'email', 'profile', 'bio', 'location'];
    const requestUpdates = Object.keys(req.body);

    // Filter allowed fields only
    const isValid = requestUpdates.every(key => allowedUpdates.includes(key));
    if (!isValid) {
      return res.status(400).json({ message: "Invalid fields in update request" });
    }

    const updatedUser = await User.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    ).select('-password');

    if (!updatedUser)
      return res.status(404).json({ message: "User not found" });

    res.json({
      message: "Profile updated successfully",
      user: updatedUser
    });

  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});



module.exports = router;
