const router = require('express').Router();
const Issue = require('../models/Issue');
const auth = require('./authMiddleware');

// CREATE ISSUE (Report Issue page)
router.post('/', auth, async (req, res) => {
  try {
    const { title, description, category, location } = req.body;

    if (!title || !description || !category) {
      return res.status(400).json({ message: 'Title, description and category are required' });
    }

    const newIssue = new Issue({
      title,
      description,
      category,
      location,
      reporter: req.user.id,
    });

    const saved = await newIssue.save();
    res.status(201).json(saved);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET ALL ISSUES (Browse Page)
router.get('/', async (req, res) => {
  try {
    const issues = await Issue.find()
      .populate('reporter', 'username profile')
      .sort({ createdAt: -1 });
    res.json(issues);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET ISSUES CREATED BY LOGGED IN USER (Profile)
router.get('/posted', auth, async (req, res) => {
  try {
    const issues = await Issue.find({ reporter: req.user.id }).sort({ createdAt: -1 });
    res.json(issues);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET ISSUES VOTED BY LOGGED IN USER (Profile)
router.get('/voted', auth, async (req, res) => {
  try {
    const issues = await Issue.find({ voters: req.user.id }).sort({ createdAt: -1 });
    res.json(issues);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// GET SINGLE ISSUE (Issue Details)
router.get('/:id', async (req, res) => {
  try {
    const issue = await Issue.findById(req.params.id)
      .populate('reporter', 'username profile');

    if (!issue) return res.status(404).json({ message: "Issue not found" });

    res.json(issue);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// UPDATE ISSUE (Admin or User)
router.put('/:id', auth, async (req, res) => {
  try {
    const updated = await Issue.findByIdAndUpdate(
      req.params.id,
      req.body,
      { new: true }
    );
    res.json(updated);
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// DELETE ISSUE (Admin)
router.delete('/:id', auth, async (req, res) => {
  try {
    await Issue.findByIdAndDelete(req.params.id);
    res.json({ message: 'Issue deleted' });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

// ⭐ UPVOTE ISSUE (Like Button Feature)
router.put('/upvote/:id', auth, async (req, res) => {
  try {
    const issue = await Issue.findById(req.params.id);
    if (!issue) return res.status(404).json({ message: "Issue not found" });

    const alreadyVoted = issue.voters.some(voterId => voterId.toString() === req.user.id);
    if (alreadyVoted) {
      return res.status(400).json({ message: 'You already voted for this issue' });
    }

    issue.votes += 1;
    issue.voters.push(req.user.id);
    await issue.save();

    res.json({ message: "Upvoted", totalVotes: issue.votes });
  } catch (err) {
    res.status(500).json({ error: err.message });
  }
});

module.exports = router;
