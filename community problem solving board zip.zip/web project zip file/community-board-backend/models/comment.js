const mongoose = require('mongoose');  // <--- Add this line at the top

const commentSchema = new mongoose.Schema({
  issue:      { type: mongoose.Schema.Types.ObjectId, ref: 'Issue', required: true },
  user:       { type: mongoose.Schema.Types.ObjectId, ref: 'User', required: true },
  content:    { type: String, required: true },
}, { timestamps: true });

module.exports = mongoose.models.Comment || mongoose.model('Comment', commentSchema);
