const mongoose = require('mongoose');

const userSchema = new mongoose.Schema({
  username: { type: String, required: true, unique: true },
  email:    { type: String, required: true, unique: true },
  password: { type: String, required: true }, // hashed!
  role:     { type: String, enum: ['user', 'admin'], default: 'user' },
  profile: {
    name: String,
    avatar: String,  // image URL
    bio: String,
    location: String,
    contact: String
  },
  createdAt: { type: Date, default: Date.now },
});

module.exports = mongoose.models.User || mongoose.model('User', userSchema);
