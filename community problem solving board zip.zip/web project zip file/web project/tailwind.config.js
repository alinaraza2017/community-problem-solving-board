/** @type {import('tailwindcss').Config} */
module.exports = {
  content: [
    "./*.html",        // all HTML files in root folder
    "./**/*.html",     // all HTML files in subfolders
    "./*.js",          // all JS files in root folder
    "./**/*.js"        // all JS files in subfolders
  ],
  theme: {
    extend: {},
  },
  plugins: [],
}
